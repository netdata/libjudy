// @(#) $Revision: 4.1 $ $Source: /judy/test/manual/st_compare.c $
//=======================================================================
//   Author Douglas L. Baskins, Sept 2002.
//   Permission to use this code is freely granted, provided that this
//   statement is retained.
//   email - doug@sourcejudy.com
//=======================================================================

// Compile for choice of algorithm:

//   cc -static -O3 -o Judy_st  -DJUDYMETHOD  st_compare.c -lJudy
//   cc -static -O3 -o Hash_st  -DST_METHOD    st_compare.c 
//
// Note:  -static will generally get better performance
//
// Usage:
//
//   Judy_st     <textfile>
//   Hash_st     <textfile>
/*

This program is a framework to allow you to study the st_* routines and 
compare the speed/space with a Judy implementation of them.  I lifted 
the st_* routines (contained within) from the ruby-1.6.7 source.

The Judy source/binarys are available at <http://sourceforge.net/projects/judy>.

This is the output of this program when run on a 933Mhz P3, where domnames.txt
is a text file of most of the internet domain names.

# wc domnames.txt
28826508 28826508 488227095 domnames.txt

Let's see if it is current:

# grep -i sourcejudy domnames.txt
SOURCEJUDY.COM
SOURCEJUDY.ORG

Yep, not more than 2 months old.

# Hash_st domnames.txt 
#  lines  avg_linelen parseline  RAMused/line insert/line  lookup/line  lookup_rand   ADT
28826508   16.9 bytes  0.143 uS    24.0 bytes    1.674 uS     0.570 uS     1.056 uS st_HASH

# Judy_st domnames.txt 
#  lines  avg_linelen parseline  RAMused/line insert/line  lookup/line  lookup_rand   ADT
28826508   16.9 bytes  0.145 uS     6.8 bytes    0.472 uS     0.154 uS     0.706 uS st_JUDY

Also notice the Judy_st version used 1/2Gb less memory.
Perhaps you should do your own tests.

*/

#include <unistd.h>             // malloc()
#include <stdlib.h>		// random()
#include <stdio.h>              // printf
#include <fcntl.h>
#include <string.h>		// strcmp()
#include <errno.h>              // errno
#include <sys/mman.h>           // mmap()
#include <sys/stat.h>           // stat()
#include <sys/time.h>           // gettimeofday()


//=======================================================================
//      S T O C K   R U B Y   st.h   H E A D E R
//=======================================================================

// Include the st.h header for reduced file count

/* This is a public domain general purpose hash table package written by Peter Moore @ UCB. */

/* @(#) st.h 5.1 89/12/14 */

#ifndef ST_INCLUDED

#define ST_INCLUDED

typedef struct st_table st_table;

struct st_hash_type {
    int (*compare)();
    int (*hash)();
};

struct st_table {
    struct st_hash_type *type;
    int num_bins;
    int num_entries;
    struct st_table_entry **bins;
};

#define st_is_member(table,key) st_lookup(table,key,(char **)0)

enum st_retval {ST_CONTINUE, ST_STOP, ST_DELETE};

st_table *st_init_table();
st_table *st_init_table_with_size();
st_table *st_init_numtable();
st_table *st_init_numtable_with_size();
st_table *st_init_strtable();
st_table *st_init_strtable_with_size();
int st_delete(), st_delete_safe();
int st_insert(), st_lookup();
void st_foreach(), st_add_direct(), st_free_table(), st_cleanup_safe();
st_table *st_copy();

#define ST_NUMCMP	((int (*)()) 0)
#define ST_NUMHASH	((int (*)()) -2)

#define st_numcmp	ST_NUMCMP
#define st_numhash	ST_NUMHASH

int st_strhash();

#endif /* ST_INCLUDED */

#if (!JUDYMETHOD) && (!ST_METHOD)
#" You must:  cc -DJUDYMETHOD or -DST_METHOD"
#endif


#ifdef JUDYMETHOD
//=======================================================================
//      J U D Y   M E T H O D
//=======================================================================

#define ADTMETHOD       "st_JUDY"

#include <Judy.h>

// from st.h

//struct st_table
//{
//    struct st_hash_type *type;  /* not used */
//    int       num_bins;         /* not used */
//    int       num_entries;
//    struct st_table_entry **bins; /* JudyL array pointer */
//};

// This st_* interface is actually a terrible way to use JLG() for
// speed at low populations.

st_table *
st_init_numtable()
{
    st_table *tbl;

    tbl = malloc(sizeof(st_table));
    tbl->type = 0;
    tbl->num_entries = 0;
    tbl->num_bins = 0;
    tbl->bins = NULL;

    return tbl;
}

st_table *
st_init_strtable()	// no collisions, so the same
{
    return st_init_numtable();
}

void
st_free_table(table)	// not much to free
     st_table *table;
{
    free(table);
}

int
st_lookup(table, key, value)
     st_table *table;
     char     *key;
     char    **value;
/* Look up item in table -- return zero if not found */
{
    char     *Value;
    char    **PValue = &Value;

    JLG(PValue, (Pvoid_t)table->bins, (Word_t)key);

    if (PValue)
    {
        if (value != NULL)
            *value = *PValue;
        return 1;
    }
    return 0;
}

int
st_insert(table, key, value)
     st_table *table;
     char     *key;
     char     *value;
/* Insert an item into the table - replacing if it already exists */
{
    char    **PValue;
    PPvoid_t  PPJLArray = (Pvoid_t)&(table->bins);

    JLI(PValue, *PPJLArray, (Word_t)key);

    if (*PValue)                /* if exists */
    {
        *PValue = value;
        return 1;
    }
    else                        /* new entry */
    {
        *PValue = value;
        table->num_entries++;
        return 0;
    }
}

int
st_delete(table, keyp, value)
     st_table *table;
     char    **keyp;
     char    **value;
{
    int       Rc;
    PPvoid_t  PPJLArray = (Pvoid_t)&(table->bins);

    JLD(Rc, *PPJLArray, (Word_t)*keyp);
    if (Rc == 0)
        return 0;               /* not found */

    table->num_entries--;
    *value = *keyp;             /* not sure why */
    return 1;
}

// probably still need the st_foreach() routine -- hopefully this whole
// thing can be thrown away (dlb)

#endif // JUDYMETHOD

#ifdef ST_METHOD

//=======================================================================
//      S L I G H T L Y   M O D I F I E D   F R O M   R U B Y   st.c
//=======================================================================
// Version ruby-1.6.7 - modified to use malloc() instead of ruby_xmalloc()

#define ADTMETHOD       "st_HASH"

/* This is a public domain general purpose hash table package written by Peter Moore @ UCB. */

static	char	sccsid[] = "@(#) st.c 5.1 89/12/14 Crucible";

#include <stdio.h>

#ifdef NT
#include <malloc.h>
#endif

typedef struct st_table_entry st_table_entry;

struct st_table_entry {
    unsigned int hash;
    char *key;
    char *record;
    st_table_entry *next;
};

#define ST_DEFAULT_MAX_DENSITY 5
#define ST_DEFAULT_INIT_TABLE_SIZE 11

    /*
     * DEFAULT_MAX_DENSITY is the default for the largest we allow the
     * average number of items per bin before increasing the number of
     * bins
     *
     * DEFAULT_INIT_TABLE_SIZE is the default for the number of bins
     * allocated initially
     *
     */
static int numcmp();
static int numhash();
static struct st_hash_type type_numhash = {
    numcmp,
    numhash,
};

static int strhash();
static struct st_hash_type type_strhash = {
    strcmp,
    strhash,
};

#define xmalloc malloc
#define xcalloc calloc

static void rehash();

#define alloc(type) (type*)xmalloc((unsigned)sizeof(type))
#define Calloc(n,s) (char*)xcalloc((n),(s))

#define EQUAL(table,x,y) ((x)==(y) || (*table->type->compare)((x),(y)) == 0)

#define do_hash(key,table) (unsigned int)(*(table)->type->hash)((key))
#define do_hash_bin(key,table) (do_hash(key, table)%(table)->num_bins)

/*
 * MINSIZE is the minimum size of a dictionary.
 */

#define MINSIZE 8

/*
Table of prime numbers 2^n+a, 2<=n<=30.
*/
static long primes[] = {
	8 + 3,
	16 + 3,
	32 + 5,
	64 + 3,
	128 + 3,
	256 + 27,
	512 + 9,
	1024 + 9,
	2048 + 5,
	4096 + 3,
	8192 + 27,
	16384 + 43,
	32768 + 3,
	65536 + 45,
	131072 + 29,
	262144 + 3,
	524288 + 21,
	1048576 + 7,
	2097152 + 17,
	4194304 + 15,
	8388608 + 9,
	16777216 + 43,
	33554432 + 35,
	67108864 + 15,
	134217728 + 29,
	268435456 + 3,
	536870912 + 11,
	1073741824 + 85,
	0
};

static int
new_size(size)
    int size;
{
    int i, newsize;

#if 0
    for (i=3; i<31; i++) {
	if ((1<<i) > size) return 1<<i;
    }
    return -1;
#else
    for (i = 0, newsize = MINSIZE;
	 i < sizeof(primes)/sizeof(primes[0]);
	 i++, newsize <<= 1)
    {
	if (newsize > size) return primes[i];
    }
    /* Ran out of polynomials */
    return -1;			/* should raise exception */
#endif
}

#ifdef HASH_LOG
static int collision = 0;
static int init_st = 0;

static void
stat_col()
{
    FILE *f = fopen("/tmp/col", "w");
    fprintf(f, "collision: %d\n", collision);
    fclose(f);
}
#endif

st_table*
st_init_table_with_size(type, size)
    struct st_hash_type *type;
    int size;
{
    st_table *tbl;

#ifdef HASH_LOG
    if (init_st == 0) {
	init_st = 1;
	atexit(stat_col);
    }
#endif

    size = new_size(size);	/* round up to prime number */

    tbl = alloc(st_table);
    tbl->type = type;
    tbl->num_entries = 0;
    tbl->num_bins = size;
    tbl->bins = (st_table_entry **)Calloc(size, sizeof(st_table_entry*));

    return tbl;
}

st_table*
st_init_table(type)
    struct st_hash_type *type;
{
    return st_init_table_with_size(type, 0);
}

st_table*
st_init_numtable()
{
    return st_init_table(&type_numhash);
}

st_table*
st_init_numtable_with_size(size)
    int size;
{
    return st_init_table_with_size(&type_numhash, size);
}

st_table*
st_init_strtable()
{
    return st_init_table(&type_strhash);
}

st_table*
st_init_strtable_with_size(size)
    int size;
{
    return st_init_table_with_size(&type_strhash, size);
}

void
st_free_table(table)
    st_table *table;
{
    register st_table_entry *ptr, *next;
    int i;

    for(i = 0; i < table->num_bins; i++) {
	ptr = table->bins[i];
	while (ptr != 0) {
	    next = ptr->next;
	    free(ptr);
	    ptr = next;
	}
    }
    free(table->bins);
    free(table);
}

#define PTR_NOT_EQUAL(table, ptr, hash_val, key) \
((ptr) != 0 && (ptr->hash != (hash_val) || !EQUAL((table), (key), (ptr)->key)))

#ifdef HASH_LOG
#define COLLISION collision++
#else
#define COLLISION
#endif

#define FIND_ENTRY(table, ptr, hash_val, bin_pos) \
bin_pos = hash_val%(table)->num_bins;\
ptr = (table)->bins[bin_pos];\
if (PTR_NOT_EQUAL(table, ptr, hash_val, key)) {\
    COLLISION;\
    while (PTR_NOT_EQUAL(table, ptr->next, hash_val, key)) {\
	ptr = ptr->next;\
    }\
    ptr = ptr->next;\
}

int
st_lookup(table, key, value)
    st_table *table;
    register char *key;
    char **value;
{
    unsigned int hash_val, bin_pos;
    register st_table_entry *ptr;

    hash_val = do_hash(key, table);
    FIND_ENTRY(table, ptr, hash_val, bin_pos);

    if (ptr == 0) {
	return 0;
    } else {
	if (value != 0)  *value = ptr->record;
	return 1;
    }
}

#define ADD_DIRECT(table, key, value, hash_val, bin_pos)\
{\
    st_table_entry *entry;\
    if (table->num_entries/(table->num_bins) > ST_DEFAULT_MAX_DENSITY) {\
	rehash(table);\
        bin_pos = hash_val % table->num_bins;\
    }\
    \
    entry = alloc(st_table_entry);\
    \
    entry->hash = hash_val;\
    entry->key = key;\
    entry->record = value;\
    entry->next = table->bins[bin_pos];\
    table->bins[bin_pos] = entry;\
    table->num_entries++;\
}

int
st_insert(table, key, value)
    register st_table *table;
    register char *key;
    char *value;
{
    unsigned int hash_val, bin_pos;
    register st_table_entry *ptr;

    hash_val = do_hash(key, table);
    FIND_ENTRY(table, ptr, hash_val, bin_pos);

    if (ptr == 0) {
	ADD_DIRECT(table, key, value, hash_val, bin_pos);
	return 0;
    } else {
	ptr->record = value;
	return 1;
    }
}

void
st_add_direct(table, key, value)
    st_table *table;
    char *key;
    char *value;
{
    unsigned int hash_val, bin_pos;

    hash_val = do_hash(key, table);
    bin_pos = hash_val % table->num_bins;
    ADD_DIRECT(table, key, value, hash_val, bin_pos);
}

static void
rehash(table)
    register st_table *table;
{
    register st_table_entry *ptr, *next, **new_bins;
    int i, old_num_bins = table->num_bins, new_num_bins;
    unsigned int hash_val;

    new_num_bins = new_size(old_num_bins+1);
    new_bins = (st_table_entry**)Calloc(new_num_bins, sizeof(st_table_entry*));

    for(i = 0; i < old_num_bins; i++) {
	ptr = table->bins[i];
	while (ptr != 0) {
	    next = ptr->next;
	    hash_val = ptr->hash % new_num_bins;
	    ptr->next = new_bins[hash_val];
	    new_bins[hash_val] = ptr;
	    ptr = next;
	}
    }
    free(table->bins);
    table->num_bins = new_num_bins;
    table->bins = new_bins;
}

st_table*
st_copy(old_table)
    st_table *old_table;
{
    st_table *new_table;
    st_table_entry *ptr, *entry;
    int i, num_bins = old_table->num_bins;

    new_table = alloc(st_table);
    if (new_table == 0) {
	return 0;
    }

    *new_table = *old_table;
    new_table->bins = (st_table_entry**)
	Calloc((unsigned)num_bins, sizeof(st_table_entry*));

    if (new_table->bins == 0) {
	free(new_table);
	return 0;
    }

    for(i = 0; i < num_bins; i++) {
	new_table->bins[i] = 0;
	ptr = old_table->bins[i];
	while (ptr != 0) {
	    entry = alloc(st_table_entry);
	    if (entry == 0) {
		free(new_table->bins);
		free(new_table);
		return 0;
	    }
	    *entry = *ptr;
	    entry->next = new_table->bins[i];
	    new_table->bins[i] = entry;
	    ptr = ptr->next;
	}
    }
    return new_table;
}

int
st_delete(table, key, value)
    register st_table *table;
    register char **key;
    char **value;
{
    unsigned int hash_val;
    st_table_entry *tmp;
    register st_table_entry *ptr;

    hash_val = do_hash_bin(*key, table);
    ptr = table->bins[hash_val];

    if (ptr == 0) {
	if (value != 0) *value = 0;
	return 0;
    }

    if (EQUAL(table, *key, ptr->key)) {
	table->bins[hash_val] = ptr->next;
	table->num_entries--;
	if (value != 0) *value = ptr->record;
	*key = ptr->key;
	free(ptr);
	return 1;
    }

    for(; ptr->next != 0; ptr = ptr->next) {
	if (EQUAL(table, ptr->next->key, *key)) {
	    tmp = ptr->next;
	    ptr->next = ptr->next->next;
	    table->num_entries--;
	    if (value != 0) *value = tmp->record;
	    *key = tmp->key;
	    free(tmp);
	    return 1;
	}
    }

    return 0;
}

int
st_delete_safe(table, key, value, never)
    register st_table *table;
    register char **key;
    char **value;
    char *never;
{
    unsigned int hash_val;
    register st_table_entry *ptr;

    hash_val = do_hash_bin(*key, table);
    ptr = table->bins[hash_val];

    if (ptr == 0) {
	if (value != 0) *value = 0;
	return 0;
    }

    for(; ptr != 0; ptr = ptr->next) {
	if ((ptr->key != never) && EQUAL(table, ptr->key, *key)) {
	    table->num_entries--;
	    *key = ptr->key;
	    if (value != 0) *value = ptr->record;
	    ptr->key = ptr->record = never;
	    return 1;
	}
    }

    return 0;
}

static int
delete_never(key, value, never)
    char *key, *value, *never;
{
    if (value == never) return ST_DELETE;
    return ST_CONTINUE;
}

void
st_cleanup_safe(table, never)
    st_table *table;
    char *never;
{
    int num_entries = table->num_entries;

    st_foreach(table, delete_never, never);
    table->num_entries = num_entries;
}

void
st_foreach(table, func, arg)
    st_table *table;
    enum st_retval (*func)();
    char *arg;
{
    st_table_entry *ptr, *last, *tmp;
    enum st_retval retval;
    int i;

    for(i = 0; i < table->num_bins; i++) {
	last = 0;
	for(ptr = table->bins[i]; ptr != 0;) {
	    retval = (*func)(ptr->key, ptr->record, arg);
	    switch (retval) {
	    case ST_CONTINUE:
		last = ptr;
		ptr = ptr->next;
		break;
	    case ST_STOP:
		return;
	    case ST_DELETE:
		tmp = ptr;
		if (last == 0) {
		    table->bins[i] = ptr->next;
		} else {
		    last->next = ptr->next;
		}
		ptr = ptr->next;
		free(tmp);
		table->num_entries--;
	    }
	}
    }
}

static int
strhash(string)
    register char *string;
{
    register int c;

#ifdef HASH_ELFHASH
    register unsigned int h = 0, g;

    while ((c = *string++) != '\0') {
	h = ( h << 4 ) + c;
	if ( g = h & 0xF0000000 )
	    h ^= g >> 24;
	h &= ~g;
    }
    return h;
#elif HASH_PERL
    register int val = 0;

    while ((c = *string++) != '\0') {
	val = val*33 + c;
    }

    return val + (val>>5);
#else
    register int val = 0;

    while ((c = *string++) != '\0') {
	val = val*997 + c;
    }

    return val + (val>>5);
#endif
}

static int
numcmp(x, y)
    long x, y;
{
    return x != y;
}

static int
numhash(n)
    long n;
{
    return n;
}

#endif // ST_METHOD


//=======================================================================
//      T I M I N G   M A C R O S
//=======================================================================
// if your machine is one of the supported types in the following header
// file then uncomment this corresponding to what the header file says.
// This will give very high timing resolution.
//
// #define JU_xxxxxxx 1         // read timeit.h
// #define JU_LINUX_IA32 1      // I.E. IA32 Linux
//
//
// optional for high resolution times and include timeit.c
//#include "timeit.h"

double    DeltaUSec;            // Global for remembering delta times

#ifndef _TIMEIT_H

// Note: I have found some Linux systems (2.4.18-6mdk) to have bugs in the 
// gettimeofday() routine.  Sometimes it returns a negative ~2840 microseconds
// instead of 0 or 1.  If you use the above #include "timeit.h" and compile with
// timeit.c and use -DJU_LINUX_IA32, that problem will be eliminated.  This is
// because for delta times less than .1 sec, the hardware free running timer
// is used instead of gettimeofday().  I have found the negative time problem
// appears about 40-50 times per second with numerous gettimeofday() calls.

#define TIMER_vars(T) struct timeval __TVBeg_##T, __TVEnd_##T

#define STARTTm(T) gettimeofday(&__TVBeg_##T, NULL)

#define ENDTm(D,T)                                                      \
{                                                                       \
    gettimeofday(&__TVEnd_##T, NULL);                                   \
    (D) = (double)(__TVEnd_##T.tv_sec  - __TVBeg_##T.tv_sec) * 1E6 +    \
         ((double)(__TVEnd_##T.tv_usec - __TVBeg_##T.tv_usec));         \
}

#endif // _TIMEIT_H

//=======================================================================
//      M E M O R Y   S I Z E   M A C R O S
//=======================================================================
//      Most mallocs have mallinfo() -- worthless on 64 bit machines

// define this if your malloc does NOT have mallinfo();
#define NOMALLINFO 1

double    DeltaMem;             // for remembering

#ifndef NOMALLINFO

#include <malloc.h>

struct mallinfo malStart;

#define STARTmem malStart = mallinfo() /* works with some mallocs */
#define ENDmem                                                  \
{                                                               \
    struct mallinfo malEnd = mallinfo();                        \
/* strange little dance from signed to unsigned to double */    \
    unsigned int _un_int = malEnd.arena - malStart.arena;       \
    DeltaMem = _un_int;      /* to double */                    \
}

#else // MALLINFO

// this usually works for machines with less than 1-2Gb RAM.
// (it does not include memory ACQUIRED by mmap())

char     *malStart;

#define STARTmem (malStart = (char *)sbrk(0))
#define ENDmem                                                  \
{                                                               \
    char  *malEnd =  (char *)sbrk(0);                           \
    DeltaMem = malEnd - malStart;                               \
}

#endif // MALLINFO



//=======================================================================
//      M A I N   P R O G R A M  -by-  Doug Baskins
//=======================================================================

// error routine for system routines for accessing file

#define FILERROR                                                        \
{                                                                       \
    printf("%s: Cannot open file \"%s\": %s "                           \
		"(errno = %d)\n", argv[0], argv[1], strerror(errno),    \
		errno);                                                 \
    fprintf(stderr, "%s: Cannot open file \"%s\": %s "                  \
		"(errno = %d)\n", argv[0], argv[1], strerror(errno),    \
		errno);                                                 \
    exit(1);                                                            \
}

// error routine for malloc failure -- unclutter main program

#define MALLOCFAIL(S)                                                   \
{                                                                       \
    printf("%s: Cannot malloc(%d) at Line=%d ",argv[0], S, __LINE__);   \
    fprintf(stderr,"%s: Cannot malloc(%d) at Line=%d ", argv[0], S, 	\
		__LINE__); 						\
    exit(1);                                                            \
}


//=======================================================================
//      M E A S U R E  A D T   S P E E D  and  M E M O R Y  U S A G E
//=======================================================================

int
main(int argc, char *argv[])
{
    TIMER_vars(tm);             // declare timer variables
    int       fd;               // to read file.
    struct stat statbuf;        // to get size of file
    st_table *table;            // name of array
    char     *Pfile;            // ram address of file
    size_t    fsize;            // file size in bytes
    char     *FSmap;            // start address of mapped file
    char     *FEmap;            // end address+1 of mapped file
    char     *String;           // current address of string
    char    **PStrings;         // array of string pointers
    char     *Value;            // location for return Value
    char    **Rstring = &Value; // set up pointer for return Value
    int       StrCnt;           // line counter
    int       ii;               // temp

// CHECK FOR REQUIRED INPUT FILE PARAMETER:

    if (argc != 2)
    {
        printf("Usage: %s <text file>\n", argv[0]);
        exit(1);
    }

// GET FILE SIZE

    if (stat(argv[1], &statbuf) == -1)
        FILERROR;

    fsize = statbuf.st_size;

// OPEN INPUT FILE:

    if ((fd = open(argv[1], O_RDONLY)) == -1)
        FILERROR;

// MEMORY MAP FILE

    Pfile =
        (char *)mmap(NULL, fsize, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (Pfile == (char *)-1)
        FILERROR;

    FEmap = Pfile + fsize;      // set end+1 address

// print command name + run arguments

    printf("# ");
    for (ii = 0; ii < argc; ii++)
        printf("%s ", argv[ii]);
    printf("\n");
    fflush(stdout);

// file is in RAM, convert '\n' to '\0' -- string has to "remain in place"
// and count the strings

    for (StrCnt = 0, FSmap = Pfile; FSmap < FEmap; FSmap++)
    {
        if (*FSmap == '\n')
        {
            *FSmap = '\0';
            StrCnt++;           // count strings
        }
    }
//  get memory to store the string addresses

    PStrings = (char **)malloc(StrCnt * sizeof(char **));
    if (PStrings == NULL) MALLOCFAIL(StrCnt * sizeof(char **));

//  print header - 5 fields

    printf("#  lines  avg_linelen parseline");
    fflush(stdout);

//  in RAM, now build an array of string pointers

    STARTTm(tm);                // start timer
    for (ii = 0, String = FSmap = Pfile; FSmap < FEmap;)
    {
        if (*FSmap++ == '\0')
        {
            PStrings[ii++] = String;
            String = FSmap;
        }
    }
    ENDTm(DeltaUSec, tm);       // end timer

    printf("  RAMused/line insert/line  lookup/line  lookup_rand   ADT\n");

//  print numb lines  filesize/line

    printf("%8u", StrCnt);      // Number of lines
    printf(" %6.1f bytes", (double)fsize / (double)StrCnt); // filesize/line
    fflush(stdout);

//  print time to parse a line -- just for fun

    printf(" %6.3f uS", DeltaUSec / (double)StrCnt);
    fflush(stdout);

//  allocate "name" structure for array

#ifdef INIT_STRTABLE
    table = st_init_strtable();  // this take about 2X longer
#else 
    table = st_init_numtable();
#endif 
    
// INPUT/STORE LOOPS:

//  insert string (address) into ADT

    STARTmem;                   // current malloc() mem usage
    STARTTm(tm);                // start timer

    for (ii = 0; ii < StrCnt; ii++)
    {
        String = PStrings[ii];
        st_insert(table, String, String); // cannot be dups
    }
    ENDTm(DeltaUSec, tm);       // end timer
    ENDmem;                     // current malloc() mem usage

//  print RAM used by malloc() by ADT to store data

    printf(" %7.1f bytes", (double)DeltaMem / (double)StrCnt);

//  print time per line to store the data

    printf(" %8.3f uS", DeltaUSec / (double)StrCnt);
    fflush(stdout);

// READ BACK LOOP

    STARTTm(tm);                // start timer

    for (ii = 0; ii < StrCnt; ii++)
    {
        String = PStrings[ii];

        st_lookup(table, String, Rstring);      // is it in array?
        if (String != Value)
        {
            fprintf(stderr, "\nOops Bug, Value does not match\n\n");
            printf("\nOops Bug, Value does not match\n\n");
            exit(1);
        }
    }
    ENDTm(DeltaUSec, tm);       // end timer

//  print time per line to lookup the data from the ADT

    printf(" %9.3f uS", DeltaUSec / (double)StrCnt); // read time/line
    fflush(stdout);

// swap PString[Index] with another random location in array

    for (ii = 0; ii < StrCnt; ii++)
    {
	char    *dataval;
	long     ranii;
	long	 seed;

        seed            = random();
        ranii           = seed % StrCnt;
        dataval         = PStrings[ii];
	PStrings[ii]    = PStrings[ranii];
        PStrings[ranii] = dataval;
    }

// READ BACK LOOP in random order

    STARTTm(tm);                // start timer

    for (ii = 0; ii < StrCnt; ii++)
    {
        String = PStrings[ii];

        st_lookup(table, String, Rstring);      // is it in array?
        if (String != Value)
        {
            fprintf(stderr, "\nOops Bug, Value does not match\n\n");
            printf("\nOops Bug, Value does not match\n\n");
            exit(1);
        }
    }
    ENDTm(DeltaUSec, tm);       // end timer

//  print time per line to lookup the data from the ADT

    printf(" %9.3f uS", DeltaUSec / (double)StrCnt); // read time/line
    printf(" %s\n", ADTMETHOD);

    return (0);                 // done

}                               // main()
