// @(#) $Revision: 4.3 $ $Source: /judy/judy/test/manual/CaptureMalloc.h,v $

//=======================================================================
//   CAPTURE MALLOC() AND FREE() TRACES AND COMPRESS TO BINARY FILE
//
//   Author Doug Baskins, August 2002.
//   Permission to use this code is freely granted, provided that this
//   statement is retained.  email - doug@sourcejudy.com
//=======================================================================

#include <stdint.h>             // typedef unsigned int uint32_t;
#include <stdio.h>              // printf etc ...

// bump the number for every new binary file file format (1st word file)
#define VERSION 0xdadde001

// generic macro to handle file system call error
#define FILERROR(SYSCLL)                                        \
{                                                               \
    printf("%s: Cannot %s() file '%s', errno = %d\n",           \
        argv[0], (SYSCLL), argv[1], errno);                     \
    exit(1);                                                    \
}

// generic macro to handle malloc failures
#define MALLOCFAIL(SIZE, LINE)  \
{                                                               \
    printf("malloc(%d) fail at line = %d\n", (int)(SIZE), LINE);\
    exit(1);                                                    \
}                                                               \

// this should be enough different malloc sizes
#define MALLOCSIZES  8192

// the 4 different trace word types
typedef enum
{
    C_c = 0,                    // calloc()
    C_m = 1,                    // malloc()
    C_r = 2,                    // realloc()
    C_f = 3                     // free()
}
twt_t;                          // trace_word_type

// the TraceWord format in binary file:
// | variable bits  |     variable bits    |  2 bits    |
//
// | malloc size ID | malloc return buf ID | trace type |
//                  ^
// The location of  | is set by SizIdSft (see below)
//
// malloc size ID (SizID) and malloc return buf ID (BufId) is an offset
// into a table that contains the malloc sizes and return buffer address.
//
typedef struct
{
    uint32_t  Version;          // Version key for marking binary file
    uint32_t  TraceCnt;         // number of trace words in binary file
    uint32_t  BufIdCnt;         // max number of active malloc()s possible
    uint32_t  SizIdCnt;         // number of SizId's
    uint32_t  SizSft;           // SizId shifted location in trace word
    uint32_t  BufTypMask;       // mask of BufId << 2 | TraceWordType
}
fhs_t, *Pfhs_t;                  // file_header_structure
