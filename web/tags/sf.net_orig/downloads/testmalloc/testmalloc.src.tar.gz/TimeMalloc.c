// @(#) $Revision: 4.1 $ $Source: /judy/test/manual/TimeMalloc.c $
//
//=======================================================================
//      M E A S U R E   M A L L O C   P E R F O R M A N C E
//
//   Author Doug Baskins, August 2002.
//   Permission to use this code is freely granted, provided that this
//   statement is retained.  email - doug@sourcejudy.com
//=======================================================================

// Compile with your favorite 'malloc'
//
//   cc  -static -O3 TimeMalloc.c  YourFavoriteMalloc.o
//
// Note:  -static will generally get a little better performance
//
// Run with a 'binary trace_in file' produced by 'CaptureMalloc'
//
//   $ TimeMalloc  binary_trace_in_file.bin
//
// No options, I tried to keep this program "mean and lean"

/* 
 * The program will suggest a -DMALLOCS=nnnnn if needed.
 * It is done this way so a malloc() of the array can be avoided.
*/

// define the following to measure the overhead in this program
// without malloc() and friends being used.
// #define TIMEIT 1

#include <unistd.h>             // size_t, ssize_t, sbrk();
#include <stdlib.h>             // exit()
#include <stdint.h>             // typedef unsigned int uint32_t;
#include <stdio.h>              // printf()
#include <fcntl.h>              // open()
#include <errno.h>              // errors that print errno

// If you created the binary file on a machine with different endianess
// and you have #include <byteswap.h> then define this:
//
// Sun(sparc), HP(pa-risc), IBM(power PC), Apple(power PC) are BIG endian
// Intel(IA32), Dec(alpha) are LITTLE endian
// Actually, modern chips (IPF) can be either, depending on the software
//
// #define S_ENDIAN 1
#ifdef S_ENDIAN
#include <byteswap.h>           // for bswap_32()
#endif
#include <sys/mman.h>           // mmap()
#include <sys/stat.h>           // stat(), open()
#include <sys/time.h>           // gettimeofday()
#include <malloc.h>             // struct mallinfo

#include "CaptureMalloc.h"      // for sibling program CaptureMalloc

// if your machine is one of the supported types in the following header
// file then uncomment this corresponding to what the header file says.
// This will give very high timing resolution.
//
// #define JU_xxxxxxx 1         // read timeit.h
// #include "timeit.h"          // optional for high resolution times

double    DeltaUSec;            // Global for remembering delta times

#ifndef _TIMEIT_H

// Note: I have found some Linux systems (2.4.18-6mdk) to have bugs in the 
// gettimeofday() routine.  Sometimes it returns a negative 2840 microseconds
// instead of 0 or 1.  If you use the above #include "timeit.h" and compile with
// timeit.c and use -DJU_LINUX_IA32, that problem will be eliminated.  This is
// because for delta times less than .1 sec, the hardware free running timer
// is used instead of gettimeofday().  I have found the negative time problem
// appears about 40-50 times per second with numerous gettimeofday() calls.

#define TIMER_vars(T) struct timeval __TVBeg_##T, __TVEnd_##T

#define STARTTm(T) gettimeofday(&__TVBeg_##T, NULL)

#define ENDTm(D,T)                                                      \
{                                                                       \
    gettimeofday(&__TVEnd_##T, NULL);                                   \
    (D) = (double)(__TVEnd_##T.tv_sec  - __TVBeg_##T.tv_sec) * 1E6 +    \
         ((double)(__TVEnd_##T.tv_usec - __TVBeg_##T.tv_usec));         \
}

#endif // _TIMEIT_H

#ifndef MALLOCS
#define MALLOCS 1000000
#endif

void     *MallocRtns[MALLOCS + 1];

uint32_t *MappedFile;           // memory mapped file pointer

uint32_t *TraceBuf;             // contains malloc/free traces

uint32_t *SizeBuf;              // buffer of all different malloc sizes

uint32_t  SizSft;               // bit shift of Sizes

uint32_t  BufTypMask;           // imported mask of all bits but sizes

//=======================================================================
//      M E M O R Y   S I Z E   M A C R O S
//=======================================================================
//      Most mallocs have mallinfo()

// define this if your malloc does not have mallinfo();
// #define NOMALLINFO

#ifndef NOMALLINFO

struct mallinfo malStart;
struct mallinfo malEnd;

#define STARTmem malStart = mallinfo() /* works with some mallocs */
#define ENDmem   malEnd   = mallinfo()
#define DeltaMem        (malEnd.arena - malStart.arena)

#else  // MALLINFO

// this usually works for machines with less than 1-2Gb RAM.
// (it does not include memory acquired by mmap())

char *malStart;
char *malEnd;

#define STARTmem (malStart = (char *)sbrk(0))
#define ENDmem   (malEnd   = (char *)sbrk(0))
#define DeltaMem (malEnd - malStart)

#endif // MALLINFO

uint32_t  Mallocs = 0;          // count malloc() deltas
uint32_t  Frees = 0;            // count free() deltas
uint32_t  Callocs = 0;          // count calloc() deltas
uint32_t  Reallocs = 0;         // count realloc() deltas

uint32_t
MeasDelta(uint32_t TraceNum, uint32_t MaxTraceNum)
{
    TIMER_vars(tm);             // declare timer variables
    uint32_t  Trace;
    uint32_t  BufId;
    uint32_t  SizId;

    Mallocs = 0;                // delta malloc()
    Frees = 0;                  // delta free()
    Reallocs = 0;               // delta realloc()
    Callocs = 0;                // delta free()

    STARTTm(tm);

    while (TraceNum < MaxTraceNum)
    {
        Trace = TraceBuf[TraceNum++];

//        printf("%4d: 0x%8x\n", TraceNum, Trace);

        if (Trace == -1)
            break;

        SizId = Trace >> SizSft;
//        BufId = (Trace & ((1 << SizSft) - 1)) / 4;
        BufId = (Trace & BufTypMask) / 4;

//        printf("type = %d, BufId = %u, SizId = %u, Size = %d\n", Trace & 3,
//               BufId, SizId, SizeBuf[SizId]);

        switch (Trace & 3)
        {
        case C_m:              // malloc
        {
            if (MallocRtns[BufId] != NULL)
            {
                printf
                    ("Oops 0x%p != NULL, BufId = %u, TraceNumb = %u, SizId = %d Line = %d \n",
                     MallocRtns[BufId], BufId, TraceNum, SizId, __LINE__);
                exit(1);
            }
#ifndef TIMEIT
            MallocRtns[BufId] = (void *)malloc(SizeBuf[SizId]);
            if (MallocRtns[BufId] == (void *)NULL)
            {
                printf
                    ("Oops - malloc(%d) failed at trace number = %u, SizId = %u Line = %d\n",
                     SizeBuf[SizId], TraceNum, SizId, __LINE__);
                exit(1);
            }
//            printf("0x%p = malloc(%d), SizId = %d, Numb = %u\n", 
//                MallocRtns[BufId], SizeBuf[SizId], SizId, TraceNum);
#endif // TIMEIT
            Mallocs++;
            break;
        }
        case C_c:              // calloc
        {
            if (MallocRtns[BufId] != NULL)
            {
                printf
                    ("Oops 0x%p != NULL, TraceNumb = %u, SizId = %d Line = %d\n",
                     MallocRtns[BufId], TraceNum, SizId, __LINE__);
                exit(1);
            }
#ifndef TIMEIT
            MallocRtns[BufId] = (void *)calloc(SizeBuf[SizId], 0);

            if (MallocRtns[BufId] == (void *)NULL)
            {
                printf
                    ("Oops - calloc(%d) failed at trace number = %u, SizId = %d Line = %d\n",
                     SizeBuf[SizId], TraceNum, SizId, __LINE__);
                exit(1);
            }
//            printf("0x%lx = malloc(%d), SizId = %d, Numb = %u\n", 
//                MallocRtns[BufId], SizeBuf[SizId], SizId, TraceNum);
#endif // TIMEIT
            Callocs++;
            break;
        }
        case C_f:              // free
        {
#ifndef TIMEIT
//            printf("0x%p = free(), Numb = %u\n", MallocRtns[BufId], TraceNum);
            free(MallocRtns[BufId]);
#endif // TIMEIT
            MallocRtns[BufId] = NULL;

            Frees++;
            break;
        }
        case C_r:              // realloc
        {
#ifndef TIMEIT
            MallocRtns[BufId] = realloc(MallocRtns[BufId], SizeBuf[SizId]);
            if (MallocRtns[BufId] == (void *)NULL)
            {
                printf
                    ("Oops - realloc(%d) failed at trace number = %u, SizId = %d\n",
                     SizeBuf[SizId], TraceNum, SizId);
                exit(1);
            }
#endif // TIMEIT
            Reallocs++;
            break;
        }
//      default:  impossible
        }
    }

    ENDTm(DeltaUSec, tm);

    return (TraceNum);
}

void
Usage(char *pname)
{
    printf("\nUsage: %s binary_trace_in_file\n\n", pname);
    exit(1);
}

//=======================================================================
//      M A I N   P R O G R A M  -by-  Doug Baskins
//=======================================================================

uint32_t  TotMalloc = 0;        // total mallocs
uint32_t  TotFree = 0;          // total frees
uint32_t  TotCalloc = 0;        // total mallocs
uint32_t  TotRealloc = 0;       // total mallocs
unsigned long Total = 0;        // all sum
double    TotalTime = 0.0;

int
main(int argc, char *argv[])
{
    int       fd;               // trace file.
    struct stat statbuf;        // to get size of file
    size_t    size;             // file size in 32 bit words
    uint32_t  SizIdCnt;         // mask of trace size to get malloc size
    uint32_t  BufIdCnt;         // mask of trace size to get malloc size
    uint32_t  TraceCnt;         // number of traces (malloc + free) in trace buffer
    uint32_t  Current;          // current total of malloc and free
    uint32_t  Delta;            // delta measurements

    Pfhs_t    Pfhs;             // ^ file_header_structure

// CHECK FOR REQUIRED INPUT FILE PARAMETER:

    if (argc != 2)
        Usage(argv[0]);
    else if (*argv[1] == '-')
        Usage(argv[0]);

// GET FILE SIZE

    if (stat(argv[1], &statbuf) == -1)
        FILERROR("stat");

    size = statbuf.st_size;

// OPEN INPUT FILE:

    if ((fd = open(argv[1], O_RDONLY)) == -1)
        FILERROR("open");

// MEMORY MAP FILE

    MappedFile =
        (uint32_t *)mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd,
                         0);
    if (MappedFile == (uint32_t *)-1)
        FILERROR("mmap");

    Pfhs = (Pfhs_t) MappedFile;

    if (Pfhs->Version != VERSION)
    {
#ifdef S_ENDIAN
        uint32_t  ii;

        if (Pfhs->Version != bswap_32(VERSION))
#endif
        {

            printf
                ("\nOops file %s is wrong format, key = 0x%x, should be = 0x%x\n\n",
                 argv[1], Pfhs->Version, VERSION);
            exit(1);
        }
#ifdef S_ENDIAN
//      change the endianess of the file -- only in ram, file is write protected
        for (ii = 0; ii < (size / sizeof(uint32_t)); ii++)
        {
            MappedFile[ii] = bswap_32(MappedFile[ii]);
        }
#endif
    }

//  init pointer and sizes

    TraceCnt = Pfhs->TraceCnt;
    BufIdCnt = Pfhs->BufIdCnt;
    SizIdCnt = Pfhs->SizIdCnt;
    SizeBuf = MappedFile + (sizeof(fhs_t) / sizeof(uint32_t));
    TraceBuf = SizeBuf + SizIdCnt;
    SizSft = Pfhs->SizSft;
    BufTypMask = Pfhs->BufTypMask;

    printf
        ("# Max concurrent mallocs = %d, Number of malloc sizes = %u, Traces = %u\n",
         BufIdCnt, SizIdCnt, TraceCnt);

//    {   // print out all malloc() sizes
//        int       ii;  
//        for (ii = 0; ii < SizIdCnt; ii++)
//            printf("Id = %d, Size = %d\n", ii, SizeBuf[ii]);
//    }

//  calculate the masks to split the trace values into size and malloc returns

    if (BufIdCnt > MALLOCS)
    {
        printf("\nOops this program must be re-compiled with at least %d:\n",
               BufIdCnt);
        printf("cc -DMALLOCS=%d ...\n\n", BufIdCnt);
        exit(1);
    }
    printf
        ("#    Total  DeltaNumb    Malloc      Free    Calloc   Realloc uSecs/call   SysBytes\n");

    STARTmem;           // mark mallocs current memory usage (from printf?)

    Current = 0;
    while (Current != TraceCnt)
    {
//      measure until a 'stopper' trace is reached
        Current = MeasDelta(Current, TraceCnt);

        Delta = Mallocs + Frees + Callocs + Reallocs;

        if (Delta == 0)
            continue;
        Total += Delta;

        ENDmem;                 // current memory from system

//      update to next trace number
        TotMalloc += Mallocs;
        TotFree += Frees;
        TotCalloc += Callocs;
        TotRealloc += Reallocs;

//      accumulate total time
        TotalTime += DeltaUSec;

        printf("%10lu %10u %9u %9u %9u %9u %10.3f %10u\n", Total, Delta,
               Mallocs, Frees, Callocs, Reallocs, DeltaUSec / Delta,
               DeltaMem);
        fflush(stdout);
    }

    printf("\n#%10lu Totals %10.3f Sec %10.3f uSec ave per call\n", Total,
           TotalTime / 1e6, TotalTime / (double)Total);

    return (0);
}
