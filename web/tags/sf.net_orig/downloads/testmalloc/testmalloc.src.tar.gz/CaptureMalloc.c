// @(#) $Revision: 4.3 $ $Source: /judy/judy/test/manual/CaptureMalloc.c,v $

//=======================================================================
//   CAPTURE MALLOC() AND FREE() TRACES AND COMPRESS TO BINARY FILE
//
//   Author Doug Baskins, August 2002.
//   Permission to use this code is freely granted, provided that this
//   statement is retained.  email - doug@sourcejudy.com
//=======================================================================

/*
 * Input Data from 'stdin' must be in the form:
 *
 *      m 0x400abcde 123             is  malloc(123);
 *      f 0x400abcde                 is  free(0x400abcde);
 *      c 0x400abcde 123             is  calloc(123);
 *      r 0x400abcde 0x400123de 123  is  realloc(0x400abcde, 123);
 *      ...
 *                          'm', 'c','r' and 'f' must be 1st column
 *                          space or tab to delimit (2nd column)
 *                          all unrecognized lines will be output to 'stdout"
 */

#include <stdlib.h>
#include <stdint.h>		// typedef unsigned int uint32_t;
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <Judy.h>
#include "CaptureMalloc.h"

uint32_t MalSizes[MALLOCSIZES];	// buffer of all malloc sizes, no order

uint32_t TraceCnt = 0;		// total number of traces
uint32_t Malloc = 0;		// total number of malloc()
uint32_t Calloc = 0;		// total number of calloc()
uint32_t Realloc = 0;		// total number of realloc()
uint32_t Free = 0;		// total number of free()
uint32_t BufIdCnt;		// max malloc concurrent buffers - 1
uint32_t SizIdCnt;		// number of different malloc sizes

uint32_t SizSft;		// (32 - number of SizIdCnt bits)
uint32_t BufTypMask;		// (1 << SizSft) - 1

Pvoid_t PLTrce = (Pvoid_t) NULL;	// storing intermediate trace words
PWord_t PLTval;			// pointer to returned trace word

Pvoid_t PLSize = (Pvoid_t) NULL;	// storing buffer malloc sizes
PWord_t PLByte;			// ^ to index into size array

Pvoid_t PLAddr = (Pvoid_t) NULL;	// holds active malloc addresses
PWord_t PLAval;
PWord_t PLAnxt;

Pvoid_t P1Numb = (Pvoid_t) NULL;	// 

int LineNumb;			// input line number (for errors)
char Line[BUFSIZ];		// read from file.

// routine to return the "mirror" of 32 bits in a 32 bit Word
// I.E.   11110001 == 10001111 but with 32 bits

uint32_t
BitMirror(uint32_t Word)
{
    Word = ((Word & 0x0000ffff) << 16) | ((Word & 0xffff0000) >> 16);
    Word = ((Word & 0x00ff00ff) << 8) | ((Word & 0xff00ff00) >> 8);
    Word = ((Word & 0x0f0f0f0f) << 4) | ((Word & 0xf0f0f0f0) >> 4);
    Word = ((Word & 0x33333333) << 2) | ((Word & 0xcccccccc) >> 2);
    Word = ((Word & 0x55555555) << 1) | ((Word & 0xaaaaaaaa) >> 1);
    return (Word);
}

// routine to combine BufId, SizId and trace type into a 32 bit word as 
// efficiently as possible (without knowing how big they are going to get.

uint32_t
FORMID(uint32_t BufId, uint32_t SizId, twt_t Typ)
{
    uint32_t BufTyp = BitMirror((BufId << 2) | Typ);
    if (BufTyp & SizId)
    {
	printf("\nOops - too many active malloc() buffers and/or sizes\n\n");
	exit(1);
    }
    return (BufTyp | SizId);
}

//  input  = | pyT |    dIfuB    |    SizID |
//  output = |    SizID |    BufId    | Typ |

uint32_t
REFORMID(uint32_t TraceValue)
{
    uint32_t SizId = TraceValue << SizSft;
    uint32_t Buf_Typ = BitMirror(TraceValue) & BufTypMask;

    return (Buf_Typ | SizId);
}

// SizId =  TraceValue >> SizSft;
// BufId = (TraceValue & ((1 << SizSft) - 1)) / 4;
// TypId =  TraceValue % 4;

//=======================================================================
//      R E A D   M A L L O C  &  F R E E   D A T A   F R O M   S T D I N
//=======================================================================

//  skip over spaces and tabs

#define SKIPWHITESPACE(PLINE)            \
    while (*(PLINE) == ' ' || *(PLINE) == '\t') (PLINE)++

//  skip over everything except spaces, tabs and newlines

#define SKIPNONWHITESPACE(PLINE)         \
    while (*(PLINE) != ' ' && *(PLINE) != '\t' && *(PLINE) != '\n') (PLINE)++

void
AddTrace(Trace)
{
    JLI(PLTval, PLTrce, TraceCnt);
    *PLTval = Trace;
    TraceCnt++;
}

// free the buffer
uint32_t
CapFree(Word_t mfr_free)
{
    uint32_t Trace;
    Word_t BufId;		// index into malloc return array
    int Rc;

    JLG(PLAval, PLAddr, mfr_free);	// get malloc number
    if (PLAval == (PWord_t) NULL)
    {
	printf("\nOops, free(0x%lx) non-existant, Line=%d:%s\n", mfr_free,
	       LineNumb, Line);
	exit(1);
    }
    BufId = *PLAval;		// get the BufId

    JLD(Rc, PLAddr, mfr_free);	// Delete the entry
    J1U(Rc, P1Numb, BufId);	// and free number
    if (Rc != 1)
    {
	printf("\nOops, free(0x%lx) non-existant, Line=%d:%s\n", mfr_free,
	       LineNumb, Line);
	exit(1);
    }
    Trace = FORMID(BufId, 0, C_f);
//LATER     Trace = FORMID(BufId, SizId, Type); // save Id 

//    printf("%d Free BufId = %ld\n", TraceCnt, BufId);
    return (Trace);
}

// alloc the buffer
uint32_t
CapAlloc(Word_t mfr_start, Word_t mfr_bytes, twt_t Type)
{
    Word_t mfr_next;		// next malloc start address
    Word_t mfr_end;		// last + 1 malloc address
    uint32_t SizId;		// index into size array
    Word_t BufId;
    uint32_t Trace;
    int Rc;

//  allocate a size Id if a new malloc size
    JLG(PLByte, PLSize, mfr_bytes);	// check if new size
    if (PLByte == (PWord_t) NULL)	// if new
    {
	JLI(PLByte, PLSize, mfr_bytes);	// add size
	*PLByte = SizIdCnt++;

//      check if too many malloc sizes
	if (SizIdCnt >= MALLOCSIZES)
	{
	    printf("\nOops - too many (%d) malloc() buffers sizes\n\n",
		   MALLOCSIZES);
	    exit(1);
	}
    }
    SizId = *PLByte;		// get size Id for mfr_bytes

//  end + 1 address of new malloc buffer
    mfr_end = mfr_start + mfr_bytes;

//  find a free malloc return value buffer Id 
    BufId = 0;			// start with a low number
    J1FE(Rc, P1Numb, BufId);	// find first available number
    J1S(Rc, P1Numb, BufId);	// allocate it
    if (BufId > BufIdCnt)
	BufIdCnt = BufId;	// keep max active malloc bufs

    JLG(PLAval, PLAddr, mfr_start);	// check if overlapping buf
    if (PLAval != NULL)		// must not be present
    {
	printf("\nOops - Duplicate malloc, Line=%d:%s\n\n", LineNumb, Line);
	exit(1);
    }
    JLI(PLAval, PLAddr, mfr_start);	// all active malloc addresses
    *PLAval = BufId;		// save Id for the free()

    mfr_next = mfr_start;
    JLN(PLAnxt, PLAddr, mfr_next);	// get start addr of next malloc

//  check if this buffer exists and overlaps the next buffer
    if ((PLAnxt != (PWord_t) NULL) && (mfr_end > mfr_next))
    {
	printf("\nOops - overlapping malloc buffers, Line=%d:%s\n\n",
	       LineNumb, Line);

	printf("Buffer 0x%lx of size %ld, overlaps 0x%lx\n", mfr_start,
	       mfr_bytes, mfr_next);
	exit(1);
    }
    Trace = FORMID(BufId, SizId, Type);

//    printf("%d 0x%lx = Alloc BufId = %ld, size = %ld\n", TraceCnt, mfr_start, BufId, mfr_bytes);

    return (Trace);
}

uint32_t
CapRealloc(Word_t mfr_free, Word_t mfr_start, Word_t mfr_bytes)
{
    Word_t mfr_next;		// next malloc start address
    Word_t mfr_end;		// last + 1 malloc address
    uint32_t SizId;		// index into size array
    Word_t BufId;
    uint32_t Trace;
    int Rc;

    JLG(PLAval, PLAddr, mfr_free);	// get malloc number
    if (PLAval == (PWord_t) NULL)
    {
	printf("\nOops, realloc(0x%lx), non-existant, Line=%d:%s\n",
	       mfr_free, LineNumb, Line);
	exit(1);
    }
    BufId = *PLAval;		// get the BufId

    JLD(Rc, PLAddr, mfr_free);	// Delete the entry

//  allocate a size Id if a new malloc size
    JLG(PLByte, PLSize, mfr_bytes);	// check if new size
    if (PLByte == (PWord_t) NULL)	// if new
    {
	JLI(PLByte, PLSize, mfr_bytes);	// add size
	*PLByte = SizIdCnt++;

//      check if too many malloc sizes
	if (SizIdCnt >= MALLOCSIZES)
	{
	    printf("\nOops - too many (%d) realloc() buffers sizes\n\n",
		   MALLOCSIZES);
	    exit(1);
	}
    }
    SizId = *PLByte;		// get size Id for mfr_bytes

//  end + 1 address of new malloc buffer
    mfr_end = mfr_start + mfr_bytes;

    JLG(PLAval, PLAddr, mfr_start);	// check if overlapping buf
    if (PLAval != NULL)		// must not be present
    {
	printf("\nOops - Duplicate realloc, Line=%d:%s\n\n", LineNumb, Line);
	exit(1);
    }
    JLI(PLAval, PLAddr, mfr_start);	// active malloc addresses
    *PLAval = BufId;		// save Id for the free()

    mfr_next = mfr_start;
    JLN(PLAnxt, PLAddr, mfr_next);	// get start addr of next malloc

//  check if this buffer exists and overlaps the next buffer
    if ((PLAnxt != (PWord_t) NULL) && (mfr_end > mfr_next))
    {
	printf("\nOops - overlapping realloc buffers, Line=%d:%s\n\n",
	       LineNumb, Line);

	printf("Buffer 0x%lx of size %ld, overlaps 0x%lx\n", mfr_start,
	       mfr_bytes, mfr_next);
	exit(1);
    }
    Trace = FORMID(BufId, SizId, C_r);

//    printf("%d 0x%lx = Realloc BufId = %ld, size = %ld\n", TraceCnt, mfr_start, BufId, mfr_bytes);

    return (Trace);
}

void
ReadData(void)
{
    char *PLine;		// Line pointer
    Word_t mfr_start;		// (re)(c)(m)alloc address
    Word_t mfr_free;		// free address
    Word_t mfr_bytes;		// (re)(c)(m)alloc bytes
    Word_t Bytes;		// index into size array
    uint32_t Trace;		// word into trace buffer

// READ AND PARSE LINE:

    LineNumb = 1;
    BufIdCnt = 0;
    SizIdCnt = 0;
    TraceCnt = 0;

//  get next line from stdin

    for (; fgets(Line, BUFSIZ, stdin) != (char *)NULL; LineNumb++)
    {
//      1 Million malloc/free progress report
//        if ((LineNumb % (1 << 20)) == 0) fprintf(stderr, "."); 

//        printf("Line %d:%s", LineNumb, Line);

	PLine = Line;		// current pointer into string

	SKIPNONWHITESPACE(PLine);	// advance to next word

	switch (Line[0])	// switch on 1st character
	{
	case 'c':		// calloc(), same as malloc
	    {
		if (strncmp(Line, "calloc", PLine - Line))
		    break;

		SKIPWHITESPACE(PLine);	// advance to malloc start

//          must be a non-zero malloc address and in hex
		if ((mfr_start = strtoul(PLine, (char **)NULL, 16)) == 0)
		    break;

		SKIPNONWHITESPACE(PLine);	// advance past malloc address
		SKIPWHITESPACE(PLine);	// advance to malloc size

//          get calloc size in any base
		mfr_bytes = strtoul(PLine, (char **)NULL, 0);

//          alloc the buffer
		Trace = CapAlloc(mfr_start, mfr_bytes, C_c);

//          Add this calloc to the trace array
		AddTrace(Trace);
		Calloc++;
		continue;
	    }
	case 'm':		// malloc()
	    {
		if (strncmp(Line, "malloc", PLine - Line))
		    break;

		SKIPWHITESPACE(PLine);	// advance to malloc start

//          must be a non-zero malloc address and in hex
		if ((mfr_start = strtoul(PLine, (char **)NULL, 16)) == 0)
		    break;

		SKIPNONWHITESPACE(PLine);	// advance past malloc address
		SKIPWHITESPACE(PLine);	// advance to malloc size

//          get malloc size in any base
		mfr_bytes = strtoul(PLine, (char **)NULL, 0);

//          alloc the buffer
		Trace = CapAlloc(mfr_start, mfr_bytes, C_m);

//          Add this malloc to the trace array
		AddTrace(Trace);
		Malloc++;
		continue;
	    }
	case 'f':		// free()
	    {
		if (strncmp(Line, "free", PLine - Line))
		    break;

		SKIPWHITESPACE(PLine);	// advance to free start

//          MUST be a non-zero free address
		if ((mfr_free = strtoul(PLine, (char **)NULL, 16)) == 0)
		    break;	// ignore it

//          free the buffer
		Trace = CapFree(mfr_free);

//          Add this free to the trace array
		AddTrace(Trace);
		Free++;
		continue;
	    }
	case 'r':		// realloc()
	    {
		if (strncmp(Line, "realloc", PLine - Line))
		    break;

		SKIPWHITESPACE(PLine);	// advance to realloc start

//          get realloc free buffer in hex
		if ((mfr_free = strtoul(PLine, (char **)NULL, 16)) == 0)
		    break;

		SKIPNONWHITESPACE(PLine);	// advance past realloc address
		SKIPWHITESPACE(PLine);	// advance to realloc size

//          get malloc size in any base
		mfr_bytes = strtoul(PLine, (char **)NULL, 0);

		SKIPNONWHITESPACE(PLine);	// advance to realloc size
		SKIPWHITESPACE(PLine);	// advance to realloc addrs

//          must be a non-zero realloc address and in hex
		mfr_start = strtoul(PLine, (char **)NULL, 16);

//          alloc the buffer
		Trace = CapRealloc(mfr_free, mfr_start, mfr_bytes);

		AddTrace(Trace);
		Realloc++;
		continue;
	    }
	default:
	    break;
	}
	AddTrace(-1);

	printf("%s", Line);	// print all lines not parsed
    }				// while.

//  Done processing all input from stdin.  There are now 2 Judy arrays that contain
//  enough information to recreate the malloc and frees
//
//  PLTrce is is simply the trace 0..N, each element is a malloc or free request.
//  The value is the malloc size Id and location Id to save the address returned.
//  If the size Id = 0, then it is a free request.
//
//  PLAddr is changed into an uninitialized linear array of BufIdCnt + 1.

    JLFA(Bytes, PLAddr);	// no longer needed.
    J1FA(Bytes, P1Numb);	// no longer needed.

    printf
	("Stats: malloc=%u realloc=%u calloc=%u free=%u total=%u concurrent=%u sizes=%u\n",
	 Malloc, Realloc, Calloc, Free, TraceCnt, BufIdCnt, SizIdCnt);

}				// ReadData()

void
Usage(char *Progname)
{
    printf("\n Usage: %s TraceoutData.bin  <  TraceinData.asc\n", Progname);
    printf
	("\nFrom ascii trace data produced from malloc() and free(), generate a\n");
    printf
	("compressed binary output trace file suitable to the 'TimeMalloc'\n");
    printf
	("program.  The 1st parameter is the compressed trace output file name.\n");
    printf("\nThe input 'trace' data is in the form:\n\n");
    printf("m 0x4012340 123            is  0x4012340 = malloc(123);\n");
    printf("c 0x4012340 123            is  0x4012340 = calloc(123);\n");
    printf("f 0x4012340                is  free(0x4012340);\n");
    printf
	("r 0x4012340 123 0x4043210  is  0x4043210 = realloc(0x4012340 , 123);\n");
    printf(" All unrecognized trace data is passed from stdin to stdout\n\n");
    exit(1);
}

int
main(int argc, char *argv[])
{
    int fd;			// for write(2)
    ssize_t ssize;		// for write(2)
    size_t size;		// for write(2)
    uint32_t *TraceBuf;		// trace info

    Word_t Bytes;		// temps
    uint32_t MaxBufId;		// temps
    uint32_t MaxSizId;		// temps
    uint32_t BufId;		// index into buffer array
    fhs_t Headr;		// file header structure

    if (argc != 2)
	Usage(argv[0]);		// print Usage:

//  open/creat the output binary trace file
    if ((fd = open(argv[1], O_RDWR)) != -1)
    {
//      check it was a trace file in the past
	ssize = read(fd, &Headr, sizeof(Headr));
	if (ssize != 0)
	{
	    if ((ssize != sizeof(Headr)) || (Headr.Version != VERSION))
	    {
		printf
		    ("\nOops cannot write to file %s, (perhaps delete it?)\n\n",
		     argv[1]);
		exit(1);
	    }
	}
	close(fd);
    }

//  create the binary output trace file
    fd = open(argv[1], O_WRONLY | O_CREAT, 0644);
    if (fd == -1)
	FILERROR("creat");

//  input ascii trace data from 'stdin'

    ReadData();

//  round up SizIdCnt to power of 2 size for size mask
    for (MaxSizId = 0; ((1 << MaxSizId) - 1) < SizIdCnt; MaxSizId++);

//    printf("MaxSizId   = 0x%x, %u\n", MaxSizId, MaxSizId);

    SizSft = (sizeof(uint32_t) * 8) - MaxSizId;
    BufTypMask = (1 << SizSft) - 1;

//    printf("SizSft     = 0x%x, %u\n", SizSft, SizSft);
//    printf("BufTypMask = 0x%x, %u\n", BufTypMask, BufTypMask);

//  write a trace file

    Headr.Version = VERSION;
    Headr.TraceCnt = TraceCnt;
    Headr.BufIdCnt = BufIdCnt;
    Headr.SizIdCnt = SizIdCnt;
    Headr.SizSft = SizSft;
    Headr.BufTypMask = BufTypMask;

    ssize = write(fd, &Headr, sizeof(Headr));
    if (ssize != sizeof(Headr))
	FILERROR("write");

//  round up BufIdCnt to power of 2 size for size mask
    for (MaxBufId = 1; MaxBufId < BufIdCnt; MaxBufId *= 2);

//    printf("MaxBufId = 0x%x %u\n", MaxBufId, MaxBufId);

//  copy sizes from PLSize to real array MalSizes[]

    Bytes = 0;
    JLF(PLByte, PLSize, Bytes);	// get 1st one
    while (PLByte != (PWord_t) NULL)	// more?
    {
	MalSizes[*PLByte] = Bytes;

//        printf("ID %ld = %d Bytes\n", *PLByte, MalSizes[*PLByte]);

	JLN(PLByte, PLSize, Bytes);	// next one
    }
    JLFA(Bytes, PLSize);	// free the array

//  write malloc sizes to file

    size = SizIdCnt * sizeof(uint32_t);
    ssize = write(fd, MalSizes, size);
    if (ssize != size)
	FILERROR("write");

//  Create fast, efficient structure to re-play 

    TraceBuf = (uint32_t *) malloc(TraceCnt * sizeof(uint32_t));
    if (TraceBuf == (uint32_t *) NULL)
	MALLOCFAIL(TraceCnt * sizeof(uint32_t), __LINE__);

//  copy trace memory from Judy array to real array (waste memory, I'am lazy)   

    for (BufId = 0;; BufId++)
    {
	uint32_t Trace;

	JLG(PLTval, PLTrce, BufId);

	if (PLTval == (PWord_t) NULL)
	    break;
	Trace = *PLTval;
	if (Trace == -1)
	    TraceBuf[BufId] = -1;
	else
	    TraceBuf[BufId] = REFORMID(Trace);
    }
    if (BufId != TraceCnt)
    {
	printf("Oops bug, count %u != %u\n", BufId, TraceCnt);
	exit(1);
    }

//  write out trace buffer to the binary trace file

    size = TraceCnt * sizeof(uint32_t);
    ssize = write(fd, TraceBuf, size);
    if (ssize != size)
	FILERROR("write");

    return (0);
}
