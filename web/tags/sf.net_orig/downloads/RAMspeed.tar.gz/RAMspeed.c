// @@(#) $Revision: 4.1 $ $Source: /judy/test/manual/RAMspeed.c $
/*
 *******************************************************************
 *     RAMspeed -- Measure random access times from/to memory      *
 *******************************************************************

Use, modify, and redistribute this code without permission.  However, if
you modify this code, please add your name to revision list.  Send
questions, comments, complaints, performance data, etc to doug@@fc.hp.com

                             -by- 

              Doug Baskins (4/28/2002)  doug@@fc.hp.com


Build:   cc       <optlevel> RAMspeed.c -o RAMspeed_32
                        -or-
         cc +DD64 <optlevel> RAMspeed.c -o RAMspeed_64

This program will measure the random access times of RAM in increasing
(power of 2) sizes (or expanses).

It uses a software linear feedback shift register (LSFR) to generate
"random" indexes.  The next index is stored as current value in an
array.  The expanse (or range) of the numbers are carefully controlled
to be unique over a specified (power of 2) expanse.

Notes:

I wrote this program because my brand new 1.7Ghz P4 (266Mhz bus) with
with DDR PC2100 ram actually ran SLOWER than my old 750Mhz P3 with SDRAM
PC100 ram.  This program reveals at least one reason why. 

I encourage you to run this program on your machine and give feedback to
the manufacturer/designer if you like or do not like the numbers you
measure.

Below is a comparison of the two (laptop) machines.

Notice the RAM read speed is about 25% slower with greater than 2Mb of data.
 
# RAMspeed 64 : Megabytes with malloc(4194304)'s

750Mhz P3, PC100 (Dell 5000e)   vs.  1.7Ghz P4, DDR PC2100 (Dell 8200)

                        750 MHz Pentium 3             1.7 GHz Pentium 4
                       -------------------           -------------------
 Accesses  Bytes used  Write(nS)  Read(nS)           Write(nS)  Read(nS)
    32768      131072      47.5      18.1                38.0      24.1
    65536      262144      45.0      50.6                32.5      27.1
   131072      524288      84.9      99.2                48.9      74.3
   262144     1048576     119.8     130.7               109.7     139.8
   524288     2097152     140.7     151.0               139.5     185.4
  1048576     4194304     153.7     158.9               153.5     210.0
  2097152     8388608     165.9     163.9               157.1     223.6
  4194304    16777216     174.6     168.8               160.5     228.9
  8388608    33554432     186.4     173.5               162.8     231.9
 16777216    67108864     199.9     186.3               165.1     238.1

________________________________________________________________________
Let my throw in results from a proto 2.40GHz machine just so I won't seem
to bigoted (against Dell Inspiron 8200).

Intel(R) XEON(TM) CPU 2.40GHz
# RAMspeed 1024 : Megabytes with malloc(4194304)'s

# Accesses  Megabytes  Write(nS)  Read(nS)
     32768        0.1      21.7      11.9
     65536        0.3      18.0      13.9
    131072        0.5      34.1      46.2
    262144        1.0      74.8     129.2
    524288        2.1      88.7     177.3
   1048576        4.2      94.0     202.9
   2097152        8.4      90.8     217.0
   4194304       16.8      90.5     224.9
   8388608       33.6      91.5     229.4
  16777216       67.1      92.3     236.6
  33554432      134.2      95.6     253.3
  67108864      268.4     111.5     293.3
 134217728      536.9     156.8     347.0
 268435456     1073.7     200.1     389.7

Note that the XEON is very good at writes, but not with reads.
Writes can be handled with a highly pipelined processor.

________________________________________________________________________

This is an old N-class HP 550Mhz PA-RISC processor (8600) running HP-UX.
This is a 32Gb machine -- so this is a 16Gb working set.

# Rs_judyn_64 16384 : Megabytes with malloc(4194304)'s

# Accesses  Megabytes  Write(nS)  Read(nS)
     32768        0.1     446.3      16.5
     65536        0.3      39.6      17.1
    131072        0.5      32.8      16.5
    262144        1.0      62.7      17.9
    524288        2.1     131.7     149.2
   1048576        4.2     157.6     212.5
   2097152        8.4     173.1     244.4
   4194304       16.8     188.4     259.4
   8388608       33.6     182.2     266.3
  16777216       67.1     193.5     269.8
  33554432      134.2     186.4     271.6
  67108864      268.4     194.6     272.3
 134217728      536.9     185.2     273.4
 268435456     1073.7     196.6     273.4
 536870912     2147.5     186.3     274.8
1073741824     4295.0     187.1     276.3
2147483648     8589.9     189.1     278.1
4294967296    17179.9     191.6     281.9

Note:  This was compiled 64 bit and then enabled with large pages.  This
explains the very high first Write time -- it takes a long time to make
a large page.  It is also obvious the data cache size is 1Mb from the
read times.  The most remarkable thing about this run is that it is
"possible" to get less than 300nS memory accesses with a 17Gb working
set.
________________________________________________________________________


REVISION LOG:

Rev: Date:      By whom:           Email:         Reason:

 0) 020428  Doug Baskins   doug@@fc.hp.com    Initial code
 1) YYMMDD

*/


#include <stdlib.h>             // for strtol(), malloc()
#include <stdio.h>              // for printf()
#include <sys/time.h>           // for gettimeofday()

typedef unsigned int Index_t;   // use 32 bit Indexes
typedef long long    LLint_t;   // 64 bit int (hopefully?)

#define IDXBTS (sizeof(Index_t) * 8) // number bits in Index

#define MILLION  (1 << 20)      // 1 Million

// Maximum megabytes that can be tested -- in 2^20 units.
// The below macro should be defined:
//
// #define MAXTMB ((1 << IDXBTS) / MILLION)
//
// but some compilers cannot handle the overflow of 32 bits

#define MAXTMB ((1 << (IDXBTS - 20)) * sizeof(Index_t))

//////////////////////////////////////////////////////////////
// STUFF FOR SUPPORT OF THE LSFR
//////////////////////////////////////////////////////////////

// Feedback taps for 15..32 bit registers

Index_t FeedbackTap[] = 
{
    0,0,0,0,0,0,0,0,0,0,0,0,0,0, // 1..14 -- not used
    0x2d,       // 15
    0x2d,       // 16
    0xdc0b,     // 17
    0xdc0b,     // 18
    0xdc0b,     // 19
    0xdc0b,     // 20
    0xc4fb,     // 21
    0xc4fb,     // 22
    0xc4fb,     // 23
    0x13aab,    // 24 
    0x11ca3,    // 25
    0x11ca3,    // 26
    0x11ca3,    // 27
    0x13aab,    // 28
    0x11ca3,    // 29
    0xc4fb,     // 30
    0xc4fb,     // 31
    0x13aab     // 32
};

// beginning number, small but not 0
#define STARTINDEX (0x1) 


// LSFR (pseudo random number generator)

Index_t gHighBit;               // high bit of current sized register
Index_t gFeedback;              // feedback taps of current register

// Return 0 when all numbers have been produced
Index_t static Random(Index_t Number)
{
    if (Number & gHighBit)
    {
        Number += Number;       // double
        Number ^= gFeedback;    // apply feedback
    }
    else
    {
        Number += Number;       // just double
    }
    Number &= gHighBit * 2 - 1; // mask to register size

    if (Number == STARTINDEX)   // wrapped ?
        return(0);

    return(Number);
}


// Timing routines

struct timeval TBeg, TEnd;

#define STARTTm         gettimeofday(&TBeg, NULL)
#define ENDTm           gettimeofday(&TEnd, NULL)

// Elapsed time calculation
#define DeltaUSec                                       \
    ((double)(TEnd.tv_sec - TBeg.tv_sec) * 1000000.0 + 	\
	(double)(TEnd.tv_usec - TBeg.tv_usec))

//////////////////////////////////////////////////////////////
// STORE(PUT) AND RETRIVE(GET) ARRAY MACROS
//////////////////////////////////////////////////////////////

// Many if not all operating systems do not allow a very large flat array.
// Therefore, many malloc()s of smaller buffers are used to emulate a large
// flat array.  This is a tiny performance penality with a modern machine.

// Total attemped to malloc() bytes -- used for error reporting

LLint_t TotalMb = 0;            // 16Gb for 64 bit programs

// Change this number to specify the size of the malloc()s.  I.E.  10 == 1K
// words, 20 == 1M words == 4M bytes.  For machines that have large pages,
// this should be defined to be at least that size.

#define MALLBITS (20)           // 20 == 4Mb malloc()s

#define MALLWORDS ((1 << MALLBITS))     // words per malloc()
#define MALLBYTES ((int)(MALLWORDS * sizeof(Index_t)))

// Define enough malloc buffers for a 4 Giga Index (16Gb) array
Index_t *PBuffer[1 << (32 - MALLBITS)];

// Split Index into Buffer number and Buffer offset
#define SPLIT(NUMBER,OFFSET,INDEX)                                      \
{                                                                       \
    (NUMBER) = (INDEX) >> MALLBITS;                                     \
    (OFFSET) = (INDEX) & (MALLWORDS - 1);                               \
}

// WRITE array macro

#define PUTWORD(INDEX, VALUE)  /*  Buffer[INDEX] = VALUE;  */           \
{                                                                       \
    Index_t _Bufnum, _Offset;                                           \
    SPLIT(_Bufnum, _Offset, INDEX);  /* split out Index bits */         \
                                                                        \
    if (PBuffer[_Bufnum] == (Index_t *)NULL) /* need more memory? */    \
    {                                                                   \
        TotalMb += MALLBYTES;                                           \
                                                                        \
        PBuffer[_Bufnum] = (Index_t *)malloc(MALLBYTES);                \
        if (PBuffer[_Bufnum] == (Index_t *)NULL)                        \
        {                                                               \
            printf("Oops -- could not malloc(%llu)\n\n", TotalMb);      \
            exit(1);                                                    \
        }                                                               \
    }                                                                   \
    *(PBuffer[_Bufnum] + _Offset) = (VALUE); /* put Value into array */ \
}

// READ array macro

#define GETWORD(VALUE, INDEX)  /*  VALUE = Buffer[INDEX];  */           \
{                                                                       \
    Index_t _Bufnum, _Offset;                                           \
    SPLIT(_Bufnum, _Offset, INDEX);  /* split out Index bits */         \
                                                                        \
    (VALUE) = *(PBuffer[_Bufnum] + _Offset); /* get Value from array */ \
}

// arg1 (128) is max number of megabytes to test
//
// $ RAMspeed 128


//////////////////////////////////////////////////////////////
// MAIN ROUTINE 
//////////////////////////////////////////////////////////////

int
main(int argc, char *argv[])
{
    Index_t Index;
    int     Group;
    LLint_t PopW;               // current number of writes
    LLint_t PopR;               // current number of reads
    LLint_t TWords;             // current bytes accessed
    int     MBytes;             // Max megabytes to test

//////////////////////////////////////////////////////////////
// DO PRELIMINARYS
//////////////////////////////////////////////////////////////

    MBytes = 64;                // default 64 megabytes

//  Check and get user supplied max size test in megabytes

    if (argc > 1) MBytes = atoi(argv[1]);

    if (MBytes == 0)            // if non-number input
    {
        printf("\n%s <Megabytes>\n\n", argv[0]); // usage:
        exit(1);
    }

//  Print program name and max number of megabytes to test

    printf("\n# %s %d : Megabytes with malloc(%d)'s\n\n", 
            argv[0], MBytes, MALLBYTES); 

//  Check if megabytes is an exact power of 2 and <= MAXTMB

    if ((MBytes > MAXTMB) || ((MBytes & -MBytes) != MBytes))
    {
        printf("Oops -- argv[1] is Pwr2 MBytes (1,2,4,8..%d)\n\n", MAXTMB);
        exit(1);
    }

//////////////////////////////////////////////////////////////
// BEGIN TESTS AT EACH POWER_OF_2 SIZE
//////////////////////////////////////////////////////////////

    printf("# Accesses  Megabytes  Write(nS)  Read(nS)\n"); // heading

    for (Group = 0; ; Group++)
    {
        Index_t Prev;                   // index of array
        Index_t Next;                   // index of array
        double  Dbytes;                 // current bytes
        LLint_t megabytes;              // current megabytes

        gHighBit = 1 << Group;          // calculate high bit of LSFR register
        TWords   = (LLint_t)gHighBit;   // calculate number of accesses
        TWords  *= 2;                   // you better not touch!

//      Calculate megabytes to access

        megabytes = TWords * sizeof(Index_t);
        megabytes /= (LLint_t)MILLION;  // you better not touch!

        gFeedback = FeedbackTap[Group]; // set feedback taps of LSFR
        if (gFeedback == 0) continue;   // skip non-specified expanse sizes

        printf("%10llu", TWords);       // number accesses

//      Calculate megabytes to access

        Dbytes = TWords * sizeof(Index_t);
        printf(" %10.1f", Dbytes / 1000000.0); // megabytes

        fflush(stdout);                 // don't buffer

//////////////////////////////////////////////////////////////
// CREATE/WRITE array in pseudo random order
//////////////////////////////////////////////////////////////

        Index = STARTINDEX;             // start low, but not 0
        Prev = 0;                       // init prev index
        PopW = 0LL;                     // init population

        STARTTm;                        // start time
        do {
            PopW++;                     // count indexes stored
            PUTWORD(Prev, Index);       // Buffer[Prev] = Index;

            Prev  = Index;              // save previous index
            Index = Random(Index);      // calc next index

        } while (Prev != 0);            // done?
        ENDTm;                          // elapsed time in DeltaUSec

        if (PopW != TWords)
        {
            printf("\nOops -- Bug PopW(%lld) != TWords\n\n", TWords);
            exit(1);
        }

//      Print write/create results in nanoseconds per write
        printf(" %9.1f", DeltaUSec * 1000.0 / (double)TWords);
        fflush(stdout);                 // don't buffer

//////////////////////////////////////////////////////////////
// READ in inserted order
//////////////////////////////////////////////////////////////

        Next = 0;                       // init next index
        PopR = 0LL;                     // init population

        STARTTm;                        // start time
        do {
            PopR++;                     // count indexes read
            GETWORD(Next, Next);        // Next = Buffer[Next];

        } while (Next != 0);            // done?
        ENDTm;                          // elapsed time in DeltaUSec

        if (PopW != TWords)
        {
            printf("\nOops -- Bug PopR(%lld) != TWords\n\n", PopR);
            exit(1);
        }

//      print read results in nano-seconds per read
        printf(" %9.1f\n", DeltaUSec * 1000.0 / (double)TWords);
        fflush(stdout);                 // don't buffer

        if (megabytes == MBytes) break; // Done?
    }
    return(0);
}
